package main;

import main.utils.*;

public class MapExamples {
    public static void main(String[] args) {
        Map<String, Integer> fruitTable = new ProbeHashMap<>();
        fruitTable.put("Apple", 1);
        fruitTable.put("Pear", 2);
        fruitTable.put("Banana", 3);

        for (Entry<String,Integer> item : fruitTable.entrySet()) {
            System.out.println(item.getKey() + " " + item.getValue());
        }

        Map<String, Integer> animalTable = new UnsortedTableMap<>();
        animalTable.put("Panda", 1);
        animalTable.put("Kangaroo", 2);
        animalTable.put("Chiikawa", 3);

        for (Entry<String,Integer> item : animalTable.entrySet()) {
            System.out.println(item.getKey() + " " + item.getValue());
        }

        Map<String, Integer> drinkBar = new SortedTableMap<>();
        drinkBar.put("Cola", 1);
        drinkBar.put("Coffee", 2);
        drinkBar.put("Tea", 3);

        for (Entry<String,Integer> item : drinkBar.entrySet()) {
            System.out.println(item.getKey() + " " + item.getValue());
        }

        Map<String, Integer> garden = new TreeMap<>();
        garden.put("Flower", 1);
        garden.put("Grass", 2);
        garden.put("Bamboo", 3);

        for (Entry<String,Integer> item : garden.entrySet()) {
            System.out.println(item.getKey() + " " + item.getValue());
        }
    }
}
