import java.util.HashMap;
import java.util.Map;

public class Solution_Ex3 {
	public static int[] twoSum(int[] nums, int target) {
		
        Map<Integer, Integer> hashtable = new HashMap<Integer, Integer>();
        for (int i = 0; i < nums.length; ++i) {
        	//System.out.println(target - nums[i]);
            if (hashtable.containsKey(target - nums[i])) {
                return new int[]{hashtable.get(target - nums[i]), i};
            }
            hashtable.put(nums[i], i);
        }
        return new int[0];
    }
	
	
	public static void main(String[] args) {
		//example 1
		int[] num = {2, 7, 11, 15};
		int target = 9;
		int[] output = twoSum(num, target);
		for(int i=0; i< output.length; i++) {
			System.out.println(output[i]);
		}
		
		//example 2
		/*int[] num = {3, 2, 4};
		int target = 6;
		int[] output = twoSum(num, target);
		for(int i=0; i< output.length; i++) {
			System.out.println(output[i]);
		}*/
		
		//example 3
		
		/*int[] num = {3, 3};
		int target = 6;
		int[] output = twoSum(num, target);
		for(int i=0; i< output.length; i++) {
			System.out.println(output[i]);
		}*/
	}
}