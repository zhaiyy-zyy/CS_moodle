class Solution {
    public String reorganizeString(String s) {
        int len = s.length();

        // PriorityQueue to store the frequencies of charadcters in descending order
        PriorityQueue<int[]> freqTracker = new PriorityQueue<>((a, b) -> b[1] - a[1]);

        // Array to calculate frequencies of characters. 
        // Index '0' will contains frequency of character 'a'
        int charFreq[] = new int[26];
        for(char ch: s.toCharArray())
        charFreq[ch - 'a']++;
        for(int i=0;i<26;i++)
        {
            if(charFreq[i] > 0)
            freqTracker.offer(new int[]{i, charFreq[i]});  
        }

        // This limit is half the length of string. If a characters occurs more than half the string, then we cannot reorganize the string and return ""
        int limit = ((len & 1) == 1) ? (len + 1) / 2 : len / 2;
        if(freqTracker.peek()[1] > limit)
        return "";

        // Store the string formed as character array
        char answer[] = new char[len];
        int i=0;
        while(!freqTracker.isEmpty())
        {
            // Get the character with max frequency and start filling it in alternate indices
            int topFreq[] = freqTracker.poll();
            for(;(i<len && topFreq[1] > 0);i+=2)
            {
                answer[i] = (char)('a' + topFreq[0]);
                topFreq[1]--;  
            }

            // If we reach end of array, then we start filling indices that are vacant which are odd indices  
            if(i >= len)
            i=1;

            // This loop runs when i has reached end of array but the character we got from priorityqueue still has more occurences 
            while(topFreq[1] > 0)
            {
                answer[i] = (char)('a' + topFreq[0]);
                topFreq[1]--;
                i += 2;
            }
        }
        // Return answer string
        return new String(answer);
    }
}