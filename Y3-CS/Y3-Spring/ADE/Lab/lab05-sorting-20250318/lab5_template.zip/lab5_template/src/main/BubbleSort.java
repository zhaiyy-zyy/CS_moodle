package main;

public class BubbleSort {
    /** Bubble-sort of an array of characters into non-decreasing order */
    public static void bubbleSort(char[] data) {
        // TODO
    }

    public static void main(String[] args) {
        char[] a = {'C', 'E', 'B', 'D', 'A', 'I', 'J', 'L', 'K', 'H', 'G', 'F'};
        System.out.println(java.util.Arrays.toString(a));
        bubbleSort(a);
        System.out.println(java.util.Arrays.toString(a));
    }
}
