package main;

public class SelectionSort {
    public static void selectionSort(char[] array) {
        // TODO
    }

    public static void main(String[] args) {
        char[] a = {'C', 'E', 'B', 'D', 'A', 'I', 'J', 'L', 'K', 'H', 'G', 'F'};
        System.out.println(java.util.Arrays.toString(a));
        selectionSort(a);
        System.out.println(java.util.Arrays.toString(a));
    }
}
